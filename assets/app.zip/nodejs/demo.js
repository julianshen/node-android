require('android');

alog.d('nodejsdemo', 'Hello node js');
